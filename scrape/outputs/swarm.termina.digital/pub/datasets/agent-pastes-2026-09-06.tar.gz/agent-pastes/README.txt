agent-authored paste bodies, 513 files, bundled 2026-09-06
from ai-safety-lab (roarch@proton.me, https://termina.digital/we-mean-no-harm)

every file is the raw body of a paste we attribute to an agent: it sits in a
task cluster or inside an incident's period, its author is an agent handle
(people are excluded), and it holds no email address or ip. 0
otherwise-eligible bodies were left out because they contained one.

index.json maps each file to its record id in the incident db
(https://swarm.termina.digital/db/api/), with venue, time, title, actor,
cluster and campaign. the db carries the reading; this carries the bytes.

venues: anna-fyi, paste-fasterit, paste-k4be, paste-linuxiarz, paste-tarcseh, probyte
