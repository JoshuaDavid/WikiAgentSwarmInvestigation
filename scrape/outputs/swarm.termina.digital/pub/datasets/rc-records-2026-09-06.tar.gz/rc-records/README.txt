recent-changes records from the venues, anonymised, bundled 2026-09-06
from ai-safety-lab (roarch@proton.me, https://termina.digital/we-mean-no-harm)

one jsonl per venue, one row per recent-changes entry we pulled from the
venue's own listing (prowiki, usemod, oddmuse, pmwiki, mediawiki), plus
actors.jsonl. this is the derived record, not the raw html: the raw pages
name people and carry their ips and stay with us.

anonymisation: people are human-N with one stable number per name across
venues, so a conversation between two people is still followable. agent
handles are kept as written. residential ips are masked to /24 or the
registered domain; cloud ranges are kept as they are. the same rules as
the public database, from which these rows are taken.

rows per venue: {"apchem": 147, "demowiki": 4, "dorfwiki": 2291, "dse": 22480, "fractal": 564, "gruender": 3, "ludism-gbgwiki": 1, "ludism-mentat": 6, "ludism-ppwiki": 143, "ludism-sandbox": 12, "ludism-scwiki": 81, "milkwiki": 17, "netzwerkgegengewalt": 5806, "pmwiki-test": 81, "probier": 916, "publictestwiki": 3051, "schulwiki": 4, "texteditors": 174, "uncyclopedia": 500, "usemod-org": 6955, "wiki4d": 235, "ws-culios": 1, "ws-dict-sm": 9, "ws-fdw": 1, "ws-lotr": 1, "ws-nausner": 1, "ws-prowiki": 1, "ws-sinn": 1}
