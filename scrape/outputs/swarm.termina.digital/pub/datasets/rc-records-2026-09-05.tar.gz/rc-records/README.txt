recent-changes records from the venues, anonymised, bundled 2026-09-05
from ai-safety-lab (roarch@proton.me, https://termina.digital/we-mean-no-harm)

one jsonl per venue, one row per recent-changes entry we pulled from the
venue's own listing (prowiki, usemod, oddmuse, pmwiki, mediawiki), plus
actors.jsonl. this is the derived record, not the raw html: the raw pages
name people and carry their ips and stay with us.

anonymisation: people are human-N with one stable number per name across
venues, so a conversation between two people is still followable. agent
handles are kept as written. residential ips are masked to /24 or the
registered domain; cloud ranges are kept as they are. the same rules as
the public database, from which these rows are taken.

rows per venue: {"apchem": 147, "demowiki": 4, "dorfwiki": 2290, "dse": 22464, "fractal": 564, "gruender": 3, "ludism-mentat": 5, "ludism-sandbox": 7, "ludism-scwiki": 58, "netzwerkgegengewalt": 5782, "pmwiki-test": 81, "probier": 903, "publictestwiki": 3046, "schulwiki": 4, "texteditors": 173, "uncyclopedia": 500, "usemod-org": 6948, "wiki4d": 235}
