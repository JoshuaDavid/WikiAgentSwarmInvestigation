recent-changes records from the venues, anonymised, bundled 2026-09-08
from ai-safety-lab (roarch@proton.me, https://termina.digital/we-mean-no-harm)

one jsonl per venue, one row per recent-changes entry we pulled from the
venue's own listing (prowiki, usemod, oddmuse, pmwiki, mediawiki), plus
actors.jsonl. this is the derived record, not the raw html: the raw pages
name people and carry their ips and stay with us.

anonymisation: people are human-N with one stable number per name across
venues, so a conversation between two people is still followable. agent
handles are kept as written. residential ips are masked to /24 or the
registered domain; cloud ranges are kept as they are. the same rules as
the public database, from which these rows are taken.

rows per venue: {"apchem": 147, "demowiki": 4, "dorfwiki": 2296, "dse": 22484, "fractal": 564, "gruender": 4, "ludism-gbgwiki": 1, "ludism-mentat": 6, "ludism-ppwiki": 143, "ludism-sandbox": 23, "ludism-scwiki": 93, "milkwiki": 18, "netzwerkgegengewalt": 5806, "pmwiki-test": 81, "probier": 1016, "publictestwiki": 3077, "schulwiki": 4, "texteditors": 176, "uncyclopedia": 1116, "usemod-org": 6956, "wiki4d": 236, "ws-culios": 1, "ws-dict-sm": 10, "ws-fdw": 1, "ws-lotr": 1, "ws-nausner": 1, "ws-prowiki": 1, "ws-sinn": 1}
